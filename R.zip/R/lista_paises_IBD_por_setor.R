#' @export

lista_paises_IBD_por_setor <- c("Países Baixos", "Ilhas Cayman", "Ilhas Virgens Britânicas", "Bahamas", "Estados Unidos", "Luxemburgo", "Áustria",
                                "Panamá", "Espanha", "Reino Unido", "Chile", "Bermudas", "Uruguai", "Portugal", "Argentina", "Colômbia", "França",
                                "Bélgica", "Suíça", "Paraguai", "México",	"Canadá",	"Peru",	"Hungria", "República Dominicana", "Venezuela",	"Suécia",
                                "Curaçao",	"Angola",	"Itália",	"Gibraltar",	"Belize",	"Alemanha",	"Ilhas Turcas e Caicos",	"Nova Zelândia",
                                "Liechtenstein",	"Ilhas Virgens(EUA)",	"Irlanda",	"Seychelles",	"Austrália",	"China",	"Japão",	"Anguila",
                                "São Vicente e Granadinas",	"Ilhas Jersey",	"Ilhas São Cristóvão e Neves",	"Cingapura",	"Hong Kong",	"Guatemala",
                                "Guernesey",	"Cuba",	"Bolívia", "África do Sul",	"Costa Rica",	"Israel",	"Malta",	"Ilhas Menores Distantes dos EUA",
                                "Tailândia",	"Equador",	"Aruba",	"Ilhas Marshall",	"Maurício",	"Ilha de Man", "Turquia",	"Antigua e Barbuda",
                                "Gana",	"El Salvador",	"Emirados Árabes Unidos",	"Líbano", "Noruega",	"Santa Lúcia",	"Índia",	"Moçambique",	"Honduras",
                                "Grécia",	"Dinamarca", "Coréia do Sul")
