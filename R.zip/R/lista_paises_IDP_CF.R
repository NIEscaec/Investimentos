

#' @export
lista_paises_IDP_CF <- c("Estados Unidos", "Espanha", "França", "Bélgica", "Reino Unido", "China", "Países Baixos", "Japão", "Alemanha",
                         "Suíça", "Luxemburgo", "Canadá", "Brasil", "Itália", "Ilhas Cayman", "Portugal", "Cingapura", "Noruega",
                         "Bermudas", "México", "Coréia do Sul", "Chile", "Suécia", "Irlanda", "Austrália", "Ilhas Virgens Britânicas",
                         "Índia", "Colômbia", "África do Sul", "Uruguai", "Argentina", "Áustria", "Panamá", "Dinamarca", "Indonésia")
